package com.twy.tripwithyou_spring.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CourseServiceImpTest {

    @Test
    void mainList() {
    }
}