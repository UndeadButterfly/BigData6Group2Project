package com.twy.tripwithyou_spring.mapper;

import com.twy.tripwithyou_spring.dto.UploadPreferDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class uploadPreferMapperTest {
    @Autowired
    UploadPreferMapper uploadPreferMapper;
    @Test
    void countByUploadPreferIsTrue() {
        System.out.println(uploadPreferMapper.countByUploadPreferIsTrue(37));;
        System.out.println(uploadPreferMapper.countByUploadPreferIsFalse(37));
    }

    @Test
    void countByUploadPreferIsFalse() {
    }

    @Test
    void insert() {
        UploadPreferDto uploadPrefer=new UploadPreferDto();
        uploadPrefer.setPrefer(true);
        uploadPrefer.setUploadNo(37);
        uploadPrefer.setUserId("user2");
        System.out.println(uploadPreferMapper.insert(uploadPrefer));
    }

    @Test
    void update() {
        UploadPreferDto uploadPrefer=uploadPreferMapper.findByUploadNoAndUserId(37,"user1");
        uploadPrefer.setPrefer(true);
        uploadPreferMapper.update(uploadPrefer);
    }

    @Test
    void delete() {
        uploadPreferMapper.delete(2);
    }

    @Test
    void findByUploadNoAndUserId() {
        System.out.println(uploadPreferMapper.findByUploadNoAndUserId(37,"user1"));
    }
}