package com.twy.tripwithyou_spring.mapper;

import com.twy.tripwithyou_spring.dto.PagingDto;
import com.twy.tripwithyou_spring.dto.ReviewDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface ReviewMapper{
    List<ReviewDto> findAll();

    List<ReviewDto> findPaging(PagingDto paging);

    int count(PagingDto paging);

    ReviewDto findById(Integer reviewNo);
    ReviewDto findByUploadNo(Integer uploadNo);
    List<ReviewDto> findByLocalNo(Integer localNo);
    List<ReviewDto> findByKindNo(Integer kindNo);

    int deleteById(Integer reviewNo);
    int deleteByUploadNo(Integer uploadNo);

    int updateById(ReviewDto review);
    int updateByUploadNo(ReviewDto review,Integer uploadNo);

    int insert(ReviewDto review);
}
