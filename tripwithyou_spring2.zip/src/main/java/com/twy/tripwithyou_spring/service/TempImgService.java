package com.twy.tripwithyou_spring.service;

import com.twy.tripwithyou_spring.dto.TempImgDto;

import java.util.List;

public interface TempImgService {
List<TempImgDto> list();


}
