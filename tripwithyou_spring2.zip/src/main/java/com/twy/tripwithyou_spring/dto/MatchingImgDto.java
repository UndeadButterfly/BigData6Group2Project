package com.twy.tripwithyou_spring.dto;

import lombok.Data;

@Data
public class MatchingImgDto {
    private int matchingImgNo;
    private int matchingNo;
    private String imgPath;
}
