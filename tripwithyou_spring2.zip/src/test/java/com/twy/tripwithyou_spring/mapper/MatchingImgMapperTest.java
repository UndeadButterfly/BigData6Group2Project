package com.twy.tripwithyou_spring.mapper;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MatchingImgMapperTest {

    @Test
    void insertOne() {
    }
}