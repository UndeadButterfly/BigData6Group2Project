package com.twy.tripwithyou_spring.dto;

import lombok.Data;

import java.util.Date;

@Data
public class ReplyDto {
    private int replyNo;
    private int uploadNo;
    private String userId;
    private String contents;
    private Date postTime;
    private Integer fkReplyNo;
}
