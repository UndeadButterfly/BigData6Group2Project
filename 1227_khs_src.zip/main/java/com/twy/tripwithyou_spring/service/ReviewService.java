package com.twy.tripwithyou_spring.service;

import com.twy.tripwithyou_spring.dto.ReviewDto;

import java.util.List;

public interface ReviewService {
    List<ReviewDto> findAll();
    ReviewDto findById();
    ReviewDto findByLocalNo();
    ReviewDto findByKindNo();
    ReviewDto findByUploadNo();
    int remove(int id);
    int register(int id);
    int modify(ReviewDto review);
}
