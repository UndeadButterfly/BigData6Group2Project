package com.twy.tripwithyou_spring.dto;

import lombok.Data;

@Data
public class AjaxStateHandler {
    private int state;
}
