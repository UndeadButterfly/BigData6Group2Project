# BigData6Group2Project
2조 프로젝트 Remote Git 저장소

Sample
*** main 태그 안에서 콘텐츠를 .row 안에 3개씩 묶어서 넣어놨는데 수정할 것임***
