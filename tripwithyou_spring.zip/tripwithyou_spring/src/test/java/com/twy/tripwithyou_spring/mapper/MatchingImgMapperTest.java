package com.twy.tripwithyou_spring.mapper;

import com.twy.tripwithyou_spring.dto.MatchingImgDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class MatchingImgMapperTest {
    @Autowired
    private MatchingImgMapper matchingImgMapper;
    @Test
    void findByMatchingNo() {
    }

    @Test
    void findOne() {
    }

    @Test
    void insertOne() {
        MatchingImgDto matchingImg=new MatchingImgDto();
        matchingImg.setMatchingNo(1);
        matchingImg.setImgPath("f.png");
        matchingImgMapper.insertOne(matchingImg);
    }
}