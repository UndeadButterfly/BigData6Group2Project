package com.twy.tripwithyou_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripwithyouSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(TripwithyouSpringApplication.class, args);
    }

}
