package com.twy.tripwithyou_spring.dto;

import lombok.Data;

@Data
public class ReviewDto extends UploadDto{
    private int reviewNo; //pk
    private int localNo; // fk 지역
    private int kindNo; // fk 활동 종류
    private int uploadNo; // fk upload 번호
    private UploadDto upload;
    private CourseDto course;
    private MatchingDto matching;
}
