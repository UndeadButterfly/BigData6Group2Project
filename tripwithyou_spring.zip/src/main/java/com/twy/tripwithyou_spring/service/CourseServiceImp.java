package com.twy.tripwithyou_spring.service;

import com.twy.tripwithyou_spring.mapper.CourseMapper;
import org.springframework.stereotype.Service;

@Service
public class CourseServiceImp implements CourseService{
    private CourseMapper courseMapper;
}
