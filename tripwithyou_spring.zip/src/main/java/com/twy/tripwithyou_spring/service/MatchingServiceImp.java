package com.twy.tripwithyou_spring.service;

import com.twy.tripwithyou_spring.mapper.MatchingMapper;
import org.springframework.stereotype.Service;

@Service
public class MatchingServiceImp implements MatchingService{
    private MatchingMapper matchingMapper;
}
