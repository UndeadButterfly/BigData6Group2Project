package com.twy.tripwithyou_spring.service;

import com.twy.tripwithyou_spring.mapper.UploadMapper;
import org.springframework.stereotype.Service;

@Service
public class UploadServiceImp implements UploadService{
    private UploadMapper uploadMapper;
}
