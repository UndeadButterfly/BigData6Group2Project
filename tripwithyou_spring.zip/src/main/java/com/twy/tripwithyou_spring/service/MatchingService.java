package com.twy.tripwithyou_spring.service;

public interface MatchingService {
}
