package com.twy.tripwithyou_spring.mapper;

import com.twy.tripwithyou_spring.dto.UploadImgDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface UploadImgMapper{

    List<UploadImgDto> findByUploadNo(int uploadNo);
    UploadImgDto findById(int uploadImgNo);
    int deleteOne(int uploadImgNo);
    int insertOne(UploadImgDto dto);
}
